dict_operations = {
    1: 'Открыть текущий справочник (вывод в консоль)',
    2: 'Добавить новую запись',
    3: 'Удалить запись',
    4: 'Поиск записи (вывод в консоль)',
    5: 'Импорт из json',
    6: 'Экспорт в json'
}

dict_field = {
    1: 'surname',
    2: 'name',
    3: 'patronimic',
    4: 'mobile',
    5: 'home_phone',
    6: 'comment'
}

dict_translate = {
    'surname': 'Фамилия',
    'name': 'Имя',
    'patronimic':  'Отчество',
    'mobile': 'Мобильный телефон',
    'home_phone': 'Домашний телефон',
    'comment': 'Описание контакта'
}
